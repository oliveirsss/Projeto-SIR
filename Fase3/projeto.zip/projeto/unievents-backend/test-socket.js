const { io } = require("socket.io-client");

const EVENT_ID = "693d93273e02b1797efc1637";

const socket = io("http://localhost:4000");

socket.on("connect", () => {
  console.log("Connected:", socket.id);

  socket.emit("join-event", EVENT_ID);

  socket.on("new-comment", (data) => {
    console.log("Novo comentário recebido:", data);
  });
});
