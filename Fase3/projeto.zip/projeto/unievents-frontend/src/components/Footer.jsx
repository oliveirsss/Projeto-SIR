export default function Footer() {
  return (
    <footer className="footer">
      UniEvents v1.0
    </footer>
  );
}
